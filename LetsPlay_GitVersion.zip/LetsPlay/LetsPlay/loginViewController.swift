//
//  ViewController.swift
//  LetsPlay
//
//  Created by Naramsetty,Jayanth on 4/4/22.
//

import UIKit

class loginViewController: UIViewController {
    @IBOutlet weak var userNameOutlet: UITextField!
    @IBOutlet weak var passwordOutlet: UITextField!
    
    @IBOutlet weak var errorMessageOutlet: UILabel!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func onSigninClick(_ sender: UIButton) {
    }
    @IBAction func onRegisterHereClick(_ sender: UIButton) {
    }
    
}

